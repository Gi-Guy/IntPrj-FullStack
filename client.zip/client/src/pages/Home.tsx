import '../styles/global.scss';

export default function Home() {
  return (
    <div className="page">
      <h1>Welcome to TaskVerse!</h1>
      <p>We're glad you're here.</p>
    </div>
  );
}